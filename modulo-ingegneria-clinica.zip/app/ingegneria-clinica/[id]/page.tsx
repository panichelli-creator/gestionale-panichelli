import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { deleteClinicalEngineeringCheck, removeClinicalEngineeringAttachment } from "@/app/actions/clinicalEngineering";

function ymd(d: Date) {
  return new Date(d).toISOString().slice(0, 10);
}

export default async function IngegneriaClinicaDetailPage({ params }: { params: { id: string } }) {
  const id = String(params.id);

  const item = await prisma.clinicalEngineeringCheck.findUnique({ where: { id } });
  if (!item) {
    return (
      <div className="card">
        <h1>Ingegneria Clinica</h1>
        <div className="muted">Voce non trovata.</div>
        <div style={{ marginTop: 12 }}>
          <Link className="btn" href="/ingegneria-clinica">Torna alla lista</Link>
        </div>
      </div>
    );
  }

  let allegati: any[] = [];
  try {
    allegati = JSON.parse(item.allegatiJson || "[]");
    if (!Array.isArray(allegati)) allegati = [];
  } catch {
    allegati = [];
  }

  const totale = Number(item.costoServizio || 0) + Number(item.importoTrasferta || 0);

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1>Ingegneria Clinica</h1>
          <div className="muted" style={{ marginTop: 4 }}>
            {item.nomeClienteSnapshot} · Prossimo app.: <b>{ymd(item.dataProssimoAppuntamento)}</b>
          </div>
        </div>

        <div className="row" style={{ gap: 8 }}>
          <Link className="btn" href="/ingegneria-clinica">Lista</Link>
          <Link className="btn" href={`/ingegneria-clinica/${id}/edit`}>Modifica</Link>

          <form action={deleteClinicalEngineeringCheck}>
            <input type="hidden" name="id" value={id} />
            <input type="hidden" name="redirectPath" value={`/ingegneria-clinica/${id}`} />
            <button className="btn" type="submit" onClick={(e) => {
              if (!confirm("Eliminare definitivamente questa voce?") ) e.preventDefault();
            }}>
              Elimina
            </button>
          </form>
        </div>
      </div>

      <div className="card" style={{ marginTop: 12 }}>
        <div className="row" style={{ gap: 18, flexWrap: "wrap" }}>
          <div>
            <div className="muted">Sede</div>
            <div>{item.indirizzoSedeSnapshot ?? ""}</div>
          </div>

          <div>
            <div className="muted">Apparecchiature</div>
            <div>
              {item.numApparecchiature}
              {item.apparecchiatureAggiuntive ? ` (+${item.apparecchiatureAggiuntive})` : ""}
            </div>
          </div>

          <div>
            <div className="muted">Costi</div>
            <div>
              Servizio: <b>{Number(item.costoServizio || 0).toFixed(2)}€</b> · Trasferta: <b>{Number(item.importoTrasferta || 0).toFixed(2)}€</b> · Totale: <b>{totale.toFixed(2)}€</b>
            </div>
            <div className="muted">Quota tecnico: {Number(item.quotaTecnico || 0).toFixed(2)}€</div>
          </div>

          <div>
            <div className="muted">Stato</div>
            <div>
              Verifiche eseguite: <b>{item.verificheEseguite ? "Sì" : "No"}</b> · File su Dropbox: <b>{item.fileSuDropbox ? "Sì" : "No"}</b> · Fatturata: <b>{item.fatturata ? "Sì" : "No"}</b>
            </div>
          </div>

          <div>
            <div className="muted">Date</div>
            <div>
              Ultimo app.: {item.dataUltimoAppuntamento ? ymd(item.dataUltimoAppuntamento) : ""}
            </div>
          </div>

          <div>
            <div className="muted">Contatti</div>
            <div className="muted">Studio: {item.contattiStudio ?? ""}</div>
            <div className="muted">Email: {item.contattiMail ?? ""}</div>
            <div className="muted">Cell.: {item.contattiCellulare ?? ""}</div>
          </div>
        </div>

        {item.notes ? (
          <div style={{ marginTop: 12 }}>
            <div className="muted">Note</div>
            <div>{item.notes}</div>
          </div>
        ) : null}
      </div>

      <div className="card" style={{ marginTop: 12 }}>
        <h2>Allegati</h2>
        {allegati.length === 0 ? (
          <div className="muted">Nessun allegato.</div>
        ) : (
          <ul>
            {allegati.map((a, idx) => (
              <li key={idx} className="row" style={{ gap: 10, alignItems: "center" }}>
                <a className="btn" href={a.url} target="_blank" rel="noreferrer">
                  Apri
                </a>
                <span>{a.name}</span>
                <span className="muted">({Math.round((a.size ?? 0) / 1024)} KB)</span>

                <form action={removeClinicalEngineeringAttachment} style={{ marginLeft: "auto" }}>
                  <input type="hidden" name="id" value={id} />
                  <input type="hidden" name="url" value={a.url} />
                  <button className="btn" type="submit" onClick={(e) => {
                    if (!confirm("Rimuovere questo allegato?") ) e.preventDefault();
                  }}>
                    Rimuovi
                  </button>
                </form>
              </li>
            ))}
          </ul>
        )}

        <div className="muted" style={{ marginTop: 8 }}>
          Per aggiungere allegati: apri “Modifica” e carica un file (verrà aggiunto in coda).
        </div>
      </div>
    </div>
  );
}
