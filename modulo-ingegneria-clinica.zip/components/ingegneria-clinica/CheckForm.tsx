import { createClinicalEngineeringCheck, updateClinicalEngineeringCheck } from "@/app/actions/clinicalEngineering";

type ClientOption = { id: string; name: string };

type CheckData = {
  id?: string;
  clientId?: string | null;
  clientSiteId?: string | null;
  nomeClienteSnapshot: string;
  indirizzoSedeSnapshot?: string | null;
  numApparecchiature: number;
  apparecchiatureAggiuntive: number;
  costoServizio: number;
  quotaTecnico: number;
  importoTrasferta: number;
  contattiStudio?: string | null;
  contattiMail?: string | null;
  contattiCellulare?: string | null;
  dataUltimoAppuntamento?: Date | null;
  dataProssimoAppuntamento: Date;
  verificheEseguite: boolean;
  fileSuDropbox: boolean;
  fatturata: boolean;
  notes?: string | null;
};

function ymd(d?: Date | null) {
  if (!d) return "";
  return new Date(d).toISOString().slice(0, 10);
}

export default function CheckForm({
  mode,
  clients,
  data,
}: {
  mode: "create" | "edit";
  clients: ClientOption[];
  data?: Partial<CheckData>;
}) {
  const action = mode === "create" ? createClinicalEngineeringCheck : updateClinicalEngineeringCheck;

  return (
    <form action={action} className="card" style={{ marginTop: 12 }} encType="multipart/form-data">
      {mode === "edit" ? (
        <input type="hidden" name="id" value={data?.id ?? ""} />
      ) : null}
      <input type="hidden" name="redirectPath" value="/ingegneria-clinica" />

      <div className="row" style={{ gap: 12, flexWrap: "wrap" }}>
        <label style={{ minWidth: 320 }}>
          <div className="muted">Cliente (collegamento gestionale)</div>
          <select name="clientId" defaultValue={data?.clientId ?? ""}>
            <option value="">— (non collegato) —</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>

        <label style={{ minWidth: 320 }}>
          <div className="muted">Nome cliente (snapshot)</div>
          <input name="nomeClienteSnapshot" defaultValue={data?.nomeClienteSnapshot ?? ""} required />
        </label>

        <label style={{ minWidth: 420, flex: 1 }}>
          <div className="muted">Sede / Indirizzo (snapshot)</div>
          <input name="indirizzoSedeSnapshot" defaultValue={data?.indirizzoSedeSnapshot ?? ""} />
        </label>
      </div>

      <div className="row" style={{ gap: 12, flexWrap: "wrap", marginTop: 12 }}>
        <label>
          <div className="muted">N° apparecchiature</div>
          <input name="numApparecchiature" type="number" min={0} defaultValue={data?.numApparecchiature ?? 0} />
        </label>
        <label>
          <div className="muted">Agg.</div>
          <input name="apparecchiatureAggiuntive" type="number" min={0} defaultValue={data?.apparecchiatureAggiuntive ?? 0} />
        </label>

        <label>
          <div className="muted">€ Servizio</div>
          <input name="costoServizio" inputMode="decimal" defaultValue={String(data?.costoServizio ?? 0)} />
        </label>
        <label>
          <div className="muted">€ Quota tecnico</div>
          <input name="quotaTecnico" inputMode="decimal" defaultValue={String(data?.quotaTecnico ?? 0)} />
        </label>
        <label>
          <div className="muted">€ Trasferta</div>
          <input name="importoTrasferta" inputMode="decimal" defaultValue={String(data?.importoTrasferta ?? 0)} />
        </label>
      </div>

      <div className="row" style={{ gap: 12, flexWrap: "wrap", marginTop: 12 }}>
        <label style={{ minWidth: 260 }}>
          <div className="muted">Ultimo appuntamento</div>
          <input name="dataUltimoAppuntamento" type="date" defaultValue={ymd(data?.dataUltimoAppuntamento ?? null)} />
        </label>

        <label style={{ minWidth: 260 }}>
          <div className="muted">Prossimo appuntamento</div>
          <input name="dataProssimoAppuntamento" type="date" defaultValue={ymd(data?.dataProssimoAppuntamento as any)} required />
        </label>
      </div>

      <div className="row" style={{ gap: 12, flexWrap: "wrap", marginTop: 12 }}>
        <label style={{ minWidth: 320 }}>
          <div className="muted">Contatti studio</div>
          <input name="contattiStudio" defaultValue={data?.contattiStudio ?? ""} />
        </label>
        <label style={{ minWidth: 320 }}>
          <div className="muted">Email</div>
          <input name="contattiMail" defaultValue={data?.contattiMail ?? ""} />
        </label>
        <label style={{ minWidth: 220 }}>
          <div className="muted">Cellulare</div>
          <input name="contattiCellulare" defaultValue={data?.contattiCellulare ?? ""} />
        </label>
      </div>

      <div className="row" style={{ gap: 16, flexWrap: "wrap", marginTop: 12 }}>
        <label className="row" style={{ gap: 8, alignItems: "center" }}>
          <input type="checkbox" name="verificheEseguite" defaultChecked={Boolean(data?.verificheEseguite)} />
          <span>Verifiche eseguite</span>
        </label>
        <label className="row" style={{ gap: 8, alignItems: "center" }}>
          <input type="checkbox" name="fileSuDropbox" defaultChecked={Boolean(data?.fileSuDropbox)} />
          <span>File su Dropbox</span>
        </label>
        <label className="row" style={{ gap: 8, alignItems: "center" }}>
          <input type="checkbox" name="fatturata" defaultChecked={Boolean(data?.fatturata)} />
          <span>Fatturata</span>
        </label>
      </div>

      <div style={{ marginTop: 12 }}>
        <div className="muted">Note</div>
        <textarea name="notes" defaultValue={data?.notes ?? ""} rows={3} />
      </div>

      <div style={{ marginTop: 12 }}>
        <div className="muted">Allegato (opzionale)</div>
        <input type="file" name="allegato" />
      </div>

      <div className="row" style={{ gap: 8, marginTop: 14 }}>
        <button className="btn" type="submit">
          {mode === "create" ? "Crea" : "Salva"}
        </button>
        <a className="btn" href="/ingegneria-clinica">Annulla</a>
      </div>
    </form>
  );
}
