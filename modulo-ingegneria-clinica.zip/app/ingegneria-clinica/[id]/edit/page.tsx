import Link from "next/link";
import { prisma } from "@/lib/prisma";
import CheckForm from "@/components/ingegneria-clinica/CheckForm";

export default async function EditIngegneriaClinicaPage({ params }: { params: { id: string } }) {
  const id = String(params.id);

  const [clients, item] = await Promise.all([
    prisma.client.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" }, take: 2000 }),
    prisma.clinicalEngineeringCheck.findUnique({ where: { id } }),
  ]);

  if (!item) {
    return (
      <div className="card">
        <h1>Ingegneria Clinica · Modifica</h1>
        <div className="muted">Voce non trovata.</div>
        <div style={{ marginTop: 12 }}>
          <Link className="btn" href="/ingegneria-clinica">Torna alla lista</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h1>Ingegneria Clinica · Modifica</h1>
        <div className="row" style={{ gap: 8 }}>
          <Link className="btn" href={`/ingegneria-clinica/${id}`}>Annulla</Link>
        </div>
      </div>

      <CheckForm
        mode="edit"
        clients={clients}
        data={{
          id: item.id,
          clientId: item.clientId,
          clientSiteId: item.clientSiteId,
          nomeClienteSnapshot: item.nomeClienteSnapshot,
          indirizzoSedeSnapshot: item.indirizzoSedeSnapshot,
          numApparecchiature: item.numApparecchiature,
          apparecchiatureAggiuntive: item.apparecchiatureAggiuntive,
          costoServizio: Number(item.costoServizio || 0),
          quotaTecnico: Number(item.quotaTecnico || 0),
          importoTrasferta: Number(item.importoTrasferta || 0),
          contattiStudio: item.contattiStudio,
          contattiMail: item.contattiMail,
          contattiCellulare: item.contattiCellulare,
          dataUltimoAppuntamento: item.dataUltimoAppuntamento,
          dataProssimoAppuntamento: item.dataProssimoAppuntamento,
          verificheEseguite: item.verificheEseguite,
          fileSuDropbox: item.fileSuDropbox,
          fatturata: item.fatturata,
          notes: item.notes,
        }}
      />

      <div className="card" style={{ marginTop: 12 }}>
        <h2>Allegati già presenti</h2>
        <div className="muted">
          Gli allegati esistenti restano invariati. Caricando un file sopra, verrà aggiunto un nuovo allegato.
        </div>
      </div>
    </div>
  );
}
