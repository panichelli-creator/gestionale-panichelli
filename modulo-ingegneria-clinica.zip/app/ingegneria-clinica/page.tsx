import Link from "next/link";
import { prisma } from "@/lib/prisma";

type SP = {
  q?: string;
  due?: string; // YYYY-MM
  fatturata?: string; // 0/1/TUTTE
};

function firstDayOfMonth(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  return new Date(Date.UTC(y, (m ?? 1) - 1, 1));
}
function firstDayNextMonth(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  return new Date(Date.UTC(y, (m ?? 1), 1));
}

export default async function IngegneriaClinicaPage({ searchParams }: { searchParams: SP }) {
  const q = String(searchParams.q ?? "").trim();

  const now = new Date();
  const defaultYm = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const due = String(searchParams.due ?? defaultYm).trim();

  const fatturata = String(searchParams.fatturata ?? "TUTTE").trim();

  const from = firstDayOfMonth(due);
  const to = firstDayNextMonth(due);

  const where: any = {
    dataProssimoAppuntamento: { gte: from, lt: to },
  };

  if (fatturata === "0") where.fatturata = false;
  if (fatturata === "1") where.fatturata = true;

  if (q) {
    where.OR = [
      { nomeClienteSnapshot: { contains: q } },
      { indirizzoSedeSnapshot: { contains: q } },
      { contattiMail: { contains: q } },
      { contattiCellulare: { contains: q } },
    ];
  }

  const items = await prisma.clinicalEngineeringCheck.findMany({
    where,
    orderBy: { dataProssimoAppuntamento: "asc" },
    take: 500,
  });

  const total = items.length;
  const totalCosti = items.reduce((s, x) => s + Number(x.costoServizio || 0) + Number(x.importoTrasferta || 0), 0);

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h1>Ingegneria Clinica</h1>
        <div className="row" style={{ gap: 8 }}>
          <Link className="btn" href="/dashboard">Dashboard</Link>
          <Link className="btn" href="/ingegneria-clinica/new">+ Nuova</Link>
        </div>
      </div>

      <div className="card" style={{ marginTop: 12 }}>
        <form className="row" style={{ gap: 8, flexWrap: "wrap" }}>
          <label className="row" style={{ gap: 6, alignItems: "center" }}>
            <span className="muted">Mese</span>
            <input name="due" defaultValue={due} placeholder="YYYY-MM" style={{ width: 120 }} />
          </label>

          <label className="row" style={{ gap: 6, alignItems: "center" }}>
            <span className="muted">Cerca</span>
            <input name="q" defaultValue={q} placeholder="cliente / email / telefono" style={{ width: 260 }} />
          </label>

          <label className="row" style={{ gap: 6, alignItems: "center" }}>
            <span className="muted">Fatturata</span>
            <select name="fatturata" defaultValue={fatturata}>
              <option value="TUTTE">Tutte</option>
              <option value="0">No</option>
              <option value="1">Sì</option>
            </select>
          </label>

          <button className="btn" type="submit">Filtra</button>

          <a
            className="btn"
            href={`/api/ingegneria-clinica/export?due=${encodeURIComponent(due)}&q=${encodeURIComponent(q)}&fatturata=${encodeURIComponent(fatturata)}`}
          >
            Export CSV
          </a>

          <div className="muted" style={{ marginLeft: "auto" }}>
            Totale: <b>{total}</b> · Valore (servizio+trasferta): <b>{totalCosti.toFixed(2)}€</b>
          </div>
        </form>
      </div>

      <div className="card" style={{ marginTop: 12, overflowX: "auto" }}>
        <table className="table" style={{ width: "100%" }}>
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Sede</th>
              <th>Prossimo app.</th>
              <th>Appar.</th>
              <th>€ Servizio</th>
              <th>€ Trasferta</th>
              <th>Fatturata</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {items.map((x) => (
              <tr key={x.id}>
                <td>{x.nomeClienteSnapshot}</td>
                <td className="muted">{x.indirizzoSedeSnapshot ?? ""}</td>
                <td>{new Date(x.dataProssimoAppuntamento).toISOString().slice(0, 10)}</td>
                <td>
                  {x.numApparecchiature}
                  {x.apparecchiatureAggiuntive ? ` (+${x.apparecchiatureAggiuntive})` : ""}
                </td>
                <td>{Number(x.costoServizio || 0).toFixed(2)}</td>
                <td>{Number(x.importoTrasferta || 0).toFixed(2)}</td>
                <td>{x.fatturata ? "Sì" : "No"}</td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <Link className="btn" href={`/ingegneria-clinica/${x.id}`}>Apri</Link>
                </td>
              </tr>
            ))}
            {items.length === 0 ? (
              <tr>
                <td colSpan={8} className="muted">Nessuna voce per i filtri selezionati.</td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
