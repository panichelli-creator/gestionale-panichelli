import Link from "next/link";
import { prisma } from "@/lib/prisma";
import CheckForm from "@/components/ingegneria-clinica/CheckForm";

export default async function NewIngegneriaClinicaPage() {
  const clients = await prisma.client.findMany({
    select: { id: true, name: true },
    orderBy: { name: "asc" },
    take: 2000,
  });

  const now = new Date();
  const nextMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, now.getUTCDate()));

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h1>Ingegneria Clinica · Nuova</h1>
        <div className="row" style={{ gap: 8 }}>
          <Link className="btn" href="/ingegneria-clinica">Indietro</Link>
        </div>
      </div>

      <div className="muted" style={{ marginTop: 6 }}>
        Suggerimento: se selezioni il cliente, puoi comunque mantenere uno “snapshot” (nome/indirizzo) per storicizzare i dati.
      </div>

      <CheckForm
        mode="create"
        clients={clients}
        data={{
          nomeClienteSnapshot: "",
          numApparecchiature: 0,
          apparecchiatureAggiuntive: 0,
          costoServizio: 0,
          quotaTecnico: 0,
          importoTrasferta: 0,
          dataProssimoAppuntamento: nextMonth,
          verificheEseguite: false,
          fileSuDropbox: false,
          fatturata: false,
        }}
      />
    </div>
  );
}
